/*
 * Copyright 1999-2020 Alibaba Group Holding Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.csp.sentinel.adapter.okhttp.extractor;

import okhttp3.Connection;
import okhttp3.Request;

/**
 * @author zhaoyuguang
 */
public interface OkHttpResourceExtractor {

    /**
     * Extracts the resource name from the HTTP request.
     *
     * @param request    HTTP request entity
     * @param connection HTTP connection
     * @return the resource name of current request
     */
    String extract(Request request, Connection connection);
}
